var NAVTREE =
[
  [ "TDA Cronologia", "index.html", [
    [ "Representación del TDA Cronolofia.", "repCronologia.html", [
      [ "Invariante de la representación", "repCronologia.html#invCronologia", null ],
      [ "Función de abstracción", "repCronologia.html#faCronologia", null ]
    ] ],
    [ "Rep del TDA EventoHistorico.", "repEventoHistorico.html", [
      [ "Invariante de la representación.", "repEventoHistorico.html#invEventoHistorico", null ],
      [ "Función de abstracción.", "repEventoHistorico.html#faEvento", null ]
    ] ],
    [ "Clases", "annotated.html", [
      [ "Lista de clases", "annotated.html", "annotated_dup" ],
      [ "Índice de clases", "classes.html", null ],
      [ "Miembros de las clases", "functions.html", [
        [ "Todo", "functions.html", null ],
        [ "Funciones", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ],
        [ "Funciones relacionadas", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Archivos", null, [
      [ "Lista de archivos", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"Cronologia_8h.html"
];

var SYNCONMSG = 'click en deshabilitar sincronización';
var SYNCOFFMSG = 'click en habilitar sincronización';