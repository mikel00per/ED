var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "Cronologia.h", "Cronologia_8h.html", [
      [ "Cronologia", "classCronologia.html", "classCronologia" ],
      [ "const_iterator", "classCronologia_1_1const__iterator.html", "classCronologia_1_1const__iterator" ],
      [ "iterator", "classCronologia_1_1iterator.html", "classCronologia_1_1iterator" ]
    ] ],
    [ "EventoHistorico.h", "EventoHistorico_8h.html", [
      [ "EventoHistorico", "classEventoHistorico.html", "classEventoHistorico" ],
      [ "const_iterator", "classEventoHistorico_1_1const__iterator.html", "classEventoHistorico_1_1const__iterator" ],
      [ "iterator", "classEventoHistorico_1_1iterator.html", "classEventoHistorico_1_1iterator" ]
    ] ]
];