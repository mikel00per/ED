var annotated_dup =
[
    [ "Cronologia", "classCronologia.html", "classCronologia" ],
    [ "EventoHistorico", "classEventoHistorico.html", "classEventoHistorico" ]
];