var menudata={children:[
{text:'Página principal',url:'index.html'},
{text:'Páginas relacionadas',url:'pages.html'},
{text:'Clases',url:'annotated.html',children:[
{text:'Lista de clases',url:'annotated.html'},
{text:'Índice de clases',url:'classes.html'},
{text:'Miembros de las clases',url:'functions.html',children:[
{text:'Todo',url:'functions.html',children:[
{text:'a',url:'functions.html#index_a'},
{text:'b',url:'functions.html#index_b'},
{text:'c',url:'functions.html#index_c'},
{text:'e',url:'functions.html#index_e'},
{text:'f',url:'functions.html#index_f'},
{text:'g',url:'functions.html#index_g'},
{text:'i',url:'functions.html#index_i'},
{text:'o',url:'functions.html#index_o'}]},
{text:'Funciones',url:'functions_func.html',children:[
{text:'a',url:'functions_func.html#index_a'},
{text:'b',url:'functions_func.html#index_b'},
{text:'c',url:'functions_func.html#index_c'},
{text:'e',url:'functions_func.html#index_e'},
{text:'f',url:'functions_func.html#index_f'},
{text:'g',url:'functions_func.html#index_g'},
{text:'i',url:'functions_func.html#index_i'},
{text:'o',url:'functions_func.html#index_o'}]},
{text:'Variables',url:'functions_vars.html'},
{text:'Funciones relacionadas',url:'functions_rela.html'}]}]},
{text:'Archivos',url:'files.html',children:[
{text:'Lista de archivos',url:'files.html'}]}]}
