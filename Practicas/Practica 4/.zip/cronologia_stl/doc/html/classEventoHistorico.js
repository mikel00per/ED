var classEventoHistorico =
[
    [ "const_iterator", "classEventoHistorico_1_1const__iterator.html", "classEventoHistorico_1_1const__iterator" ],
    [ "iterator", "classEventoHistorico_1_1iterator.html", "classEventoHistorico_1_1iterator" ],
    [ "aniadeAnio", "classEventoHistorico.html#ad7bb99f4afa1b283f965a5ed378a5c14", null ],
    [ "aniadeEvento", "classEventoHistorico.html#aedda8393e5c52b32ee3c3a5cbd58ab37", null ],
    [ "begin", "classEventoHistorico.html#a8f27947006df390ef03eab962029e14b", null ],
    [ "cbegin", "classEventoHistorico.html#a78a3ad0944311039c814e0b212e68929", null ],
    [ "cend", "classEventoHistorico.html#ab217a30a72652cabb431d7b50c9904e9", null ],
    [ "end", "classEventoHistorico.html#ac0c4b9959e20bc695d6d14c85ffa058e", null ],
    [ "getFirst", "classEventoHistorico.html#a6fc58df8314cce74171cc0ae5ab99065", null ],
    [ "insertaEventoHistorico", "classEventoHistorico.html#ad195324148f8dd147248eeb533f9e512", null ],
    [ "operator<<", "classEventoHistorico.html#aa832ccb9c8af9ae4b90ce61d84cb21b0", null ],
    [ "eventos", "classEventoHistorico.html#a6abe942b12ab22f551062d7ee9e9e02d", null ]
];